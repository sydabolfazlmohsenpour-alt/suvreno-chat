// پلِ بین چت Suvreno (chat.suvreno.ir) و افزونه: چت می‌تواند بفهمد افزونه نصب است و یک کار برایش بفرستد.
(function () {
  var V = chrome.runtime.getManifest().version, ORIGIN = location.origin;
  function ready() { window.postMessage({ source: "suvreno-agent-ext", type: "ready", version: V }, ORIGIN); }
  try { document.documentElement.setAttribute("data-suv-agent-ext", V); } catch (e) {}
  ready();
  window.addEventListener("message", function (e) {
    if (e.source !== window || e.origin !== ORIGIN) return;
    var d = e.data; if (!d || d.source !== "suvreno-chat") return;
    if (d.type === "ping") { ready(); return; }
    if (d.type === "run" && typeof d.task === "string") {
      chrome.runtime.sendMessage({ type: "suv-run", task: d.task.slice(0, 600), code: String(d.code || "").slice(0, 12) }, function (r) {
        var err = chrome.runtime.lastError;
        window.postMessage({ source: "suvreno-agent-ext", type: "run-ack", ok: !!(r && r.ok), opened: !!(r && r.opened), error: err ? String(err.message || "") : ((r && r.error) || "") }, ORIGIN);
      });
    }
  });
})();
