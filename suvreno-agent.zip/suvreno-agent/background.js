// کلیک روی آیکن افزونه، پنل کناری Suvreno Agent را باز می‌کند.
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});
chrome.runtime.onStartup.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});

// کاری که از داخل چت Suvreno فرستاده می‌شود: پنل را باز کن، یک تبِ تازه برای ایجنت بساز (تب چت دست نمی‌خورد)
// و کار را در storage.session بگذار تا پنل بردارد.
chrome.runtime.onMessage.addListener((msg, sender, send) => {
  if (!msg || msg.type !== "suv-run") return;
  if (!sender || !sender.tab || !/^https:\/\/chat\.suvreno\.ir\//.test(String(sender.url || ""))) { send({ ok: false, error: "origin" }); return; }
  (async () => {
    let opened = false;
    try { await chrome.sidePanel.open({ windowId: sender.tab.windowId }); opened = true; } catch (e) {}
    try {
      const tab = await chrome.tabs.create({ url: "https://www.google.com/", active: true, windowId: sender.tab.windowId });
      await chrome.storage.session.set({ svPending: { task: String(msg.task || "").slice(0, 600), code: String(msg.code || "").slice(0, 12), tabId: tab.id, at: Date.now() } });
      chrome.runtime.sendMessage({ type: "suv-pending" }).catch(() => {});
      send({ ok: true, opened });
    } catch (e) { send({ ok: false, error: "tab" }); }
  })();
  return true;
});

// ---- کارهای زمان‌بندی‌شده‌ی نیازمند ورود (مرحله‌ی ۳): هر ۵ دقیقه از سرور می‌پرسد «کاری سررسید شده؟».
// این پرسش همزمان نشان می‌دهد این مرورگر آنلاین است. کار فقط وقتی اجرا می‌شود که خودت در پنل «اجرا» را بزنی؛
// چون اجرای بی‌حضور روی حساب‌های واردشده خطرناک است و ایجنت برای کارهای حساس تأیید می‌خواهد.
const SV_API = "https://suvreno-plus.sydabolfazlmohsenpour.workers.dev/";
function svEnsureAlarm() { try { chrome.alarms.create("suvJobs", { delayInMinutes: 1, periodInMinutes: 5 }); } catch (e) {} }
chrome.runtime.onInstalled.addListener(svEnsureAlarm);
chrome.runtime.onStartup.addListener(() => { svEnsureAlarm(); svPollJobs(); });
async function svPollJobs() {
  let o; try { o = await chrome.storage.local.get(["svToken", "svNotified"]); } catch (e) { return; }
  if (!o.svToken) { try { chrome.action.setBadgeText({ text: "" }); } catch (e) {} return; }
  let j = null;
  try {
    const r = await fetch(SV_API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mode: "agent-jobs", agentToken: o.svToken }) });
    j = await r.json();
  } catch (e) { return; }
  if (!j || !j.ok) { if (j && j.error === "AGENT_UNAUTH") await chrome.storage.local.remove("svToken"); return; }
  const jobs = Array.isArray(j.jobs) ? j.jobs : [];
  try { chrome.action.setBadgeText({ text: jobs.length ? String(jobs.length) : "" }); chrome.action.setBadgeBackgroundColor({ color: "#e11d48" }); } catch (e) {}
  const seen = new Set(o.svNotified || []), fresh = jobs.filter(x => !seen.has(x.id));
  if (fresh.length) {
    try {
      chrome.notifications.create("suvjob-" + fresh[0].id, { type: "basic", iconUrl: "icon128.png", title: "Suvreno Agent", message: "کار زمان‌بندی‌شده آماده‌ی اجراست: " + fresh[0].title + (fresh.length > 1 ? " (و " + (fresh.length - 1) + " کار دیگر)" : "") + "\nآیکن افزونه را باز کن و «اجرا» را بزن." });
    } catch (e) {}
    await chrome.storage.local.set({ svNotified: [...seen, ...fresh.map(x => x.id)].slice(-60) });
  }
}
chrome.alarms.onAlarm.addListener(a => { if (a && a.name === "suvJobs") svPollJobs(); });
chrome.notifications.onClicked.addListener(async id => {
  if (!String(id).startsWith("suvjob-")) return;
  try { chrome.notifications.clear(id); } catch (e) {}
  try { const w = await chrome.windows.getLastFocused(); await chrome.sidePanel.open({ windowId: w.id }); } catch (e) {}
});
chrome.runtime.onMessage.addListener(m => { if (m && m.type === "suv-poll") svPollJobs(); });
svEnsureAlarm();
