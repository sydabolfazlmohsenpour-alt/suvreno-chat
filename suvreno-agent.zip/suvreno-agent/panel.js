"use strict";
/* Suvreno Agent v0.1 — حلقه‌ی ایجنت داخل پنل کناری.
   سرور فقط «یک کار بعدی» پیشنهاد می‌دهد؛ اجرا و همه‌ی کنترل‌های ایمنی همین‌جا و سمت مرورگر خود کاربر است. */
const API = "https://suvreno-plus.sydabolfazlmohsenpour.workers.dev/";
const $ = id => document.getElementById(id);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const store = {
  get: k => chrome.storage.local.get(k).then(o => o[k]),
  set: (k, v) => chrome.storage.local.set({ [k]: v }),
  del: k => chrome.storage.local.remove(k),
};
const faNum = n => Number(n || 0).toLocaleString("fa-IR");

async function api(body, timeout) {
  const ac = new AbortController(), tm = setTimeout(() => ac.abort(), timeout || 60000);
  try {
    const r = await fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: ac.signal });
    const j = await r.json().catch(() => null);
    return j || { ok: false, error: "BAD_RESPONSE", message: "پاسخ سرور نامعتبر بود." };
  } catch { return { ok: false, error: "NETWORK", message: "اتصال به Suvreno برقرار نشد؛ اینترنتت رو چک کن." }; }
  finally { clearTimeout(tm); }
}

/* ---------- ایمنی (سمت مرورگر؛ مستقل از مدل) ---------- */
const PAY_HOST_RE = /(^|\.)(shaparak\.ir|zarinpal\.com|idpay\.ir|pay\.ir|nextpay\.org|paypal\.com|stripe\.com|bmi\.ir|sep\.ir|behpardakht\.com|mellatbank\.com)$/i;
const PAY_PATH_RE = /(\/payment\b|\/pay\/|\/gateway\b|\/ipg\b|\/checkout\/pay)/i;
const SENS_RE = /(خرید|پرداخت|ثبت\s*سفارش|تکمیل|نهایی|انتشار|منتشر|ارسال|حذف|publish|buy|pay|purchase|place\s*order|checkout|submit|post|send|delete|remove|confirm)/i;
const CART_RE = /(سبد|add\s*to\s*(cart|bag|basket))/i;
const isPayUrl = u => { try { const x = new URL(u); return PAY_HOST_RE.test(x.hostname) || PAY_PATH_RE.test(x.pathname); } catch { return false; } };
const regDomain = h => {
  const p = String(h || "").toLowerCase().split(".").filter(Boolean);
  if (p.length <= 2) return p.join(".");
  const sl = new Set(["co", "com", "org", "net", "ac", "gov", "edu"]);
  return (sl.has(p[p.length - 2]) && p[p.length - 1].length === 2 ? p.slice(-3) : p.slice(-2)).join(".");
};
const hostOf = u => { try { return new URL(u).hostname; } catch { return ""; } };

/* ---------- توابعی که داخل صفحه اجرا می‌شن (کاملاً مستقل از بیرون) ---------- */
function svSnapshot() {
  try {
    const SEL = 'a[href],button,input,select,textarea,summary,[role=button],[role=link],[role=tab],[role=menuitem],[role=option],[contenteditable=""],[contenteditable="true"],[onclick]';
    const blocked = el => {
      const ty = (el.type || "").toLowerCase(), ac = (el.getAttribute("autocomplete") || "").toLowerCase();
      const nm = ((el.name || "") + " " + (el.id || "") + " " + (el.getAttribute("placeholder") || "") + " " + (el.getAttribute("aria-label") || "")).toLowerCase();
      return ty === "password" || /cc-|one-time-code/.test(ac) || /(password|passwd|cvv|cvc|otp|card.?num|cardnumber|national.?id|کد\s*ملی|رمز|کارت|پین)/.test(nm);
    };
    document.querySelectorAll("[data-sv-id]").forEach(n => n.removeAttribute("data-sv-id"));
    const vh = window.innerHeight || 800;
    const vis = el => {
      if (el.disabled) return false;
      const r = el.getBoundingClientRect(); if (r.width < 3 || r.height < 3) return false;
      const s = getComputedStyle(el); return !(s.visibility === "hidden" || s.display === "none" || Number(s.opacity) === 0);
    };
    const all = [...document.querySelectorAll(SEL)].filter(el => !(el.tagName === "INPUT" && el.type === "hidden") && vis(el));
    const inView = [], rest = [];
    for (const el of all) { const r = el.getBoundingClientRect(); (r.bottom > -100 && r.top < vh + 300 ? inView : rest).push(el); }
    const picks = inView.concat(rest).slice(0, 60);
    const here = location.hostname;
    const els = picks.map((el, k) => {
      el.setAttribute("data-sv-id", String(k));
      const tag = el.tagName.toLowerCase();
      let s = (el.getAttribute("aria-label") || el.innerText || el.textContent || "").trim();
      if (!s) s = el.getAttribute("placeholder") || el.getAttribute("title") || el.getAttribute("alt") || el.getAttribute("name") || "";
      s = s.replace(/\s+/g, " ").trim();
      if ((tag === "input" || tag === "textarea") && !blocked(el) && el.value && el.type !== "checkbox" && el.type !== "radio") s += " [مقدار: " + String(el.value).slice(0, 30) + "]";
      if (tag === "select") s += " [گزینه‌ها: " + [...el.options].slice(0, 12).map(o => o.text.trim()).join(" / ") + "]";
      if (blocked(el)) s = "(فیلد حساس؛ قابل پر کردن نیست)";
      let h = ""; if (tag === "a") { try { const u = new URL(el.href, location.href); if (u.hostname !== here) h = u.hostname; } catch {} }
      const ty = el.isContentEditable && tag !== "input" && tag !== "textarea" ? "editable" : (el.type || el.getAttribute("role") || "");
      return { i: k, t: tag, ty: String(ty).slice(0, 12), x: s.slice(0, 80), h };
    });
    let txt = (document.body ? document.body.innerText : "") || "";
    txt = txt.replace(/[ \t]+/g, " ").replace(/\n\s*\n+/g, "\n").trim().slice(0, 4000).replace(/(?:\d[ -]?){13,19}/g, "[عدد حذف شد]");
    return { url: location.href, title: document.title || "", text: txt, els };
  } catch (e) { return { url: location.href, title: "", text: "", els: [], err: String(e && e.message || e) }; }
}
function svAct(a) {
  try {
    const blocked = el => {
      const ty = (el.type || "").toLowerCase(), ac = (el.getAttribute("autocomplete") || "").toLowerCase();
      const nm = ((el.name || "") + " " + (el.id || "") + " " + (el.getAttribute("placeholder") || "") + " " + (el.getAttribute("aria-label") || "")).toLowerCase();
      return ty === "password" || /cc-|one-time-code/.test(ac) || /(password|passwd|cvv|cvc|otp|card.?num|cardnumber|national.?id|کد\s*ملی|رمز|کارت|پین)/.test(nm);
    };
    if (a.action === "scroll") { window.scrollBy({ top: (a.dir === "up" ? -1 : 1) * Math.round((window.innerHeight || 700) * 0.8), behavior: "instant" }); return { ok: true }; }
    const el = a.id != null ? document.querySelector('[data-sv-id="' + a.id + '"]') : null;
    if (!el) return { ok: false, n: "عنصر پیدا نشد (صفحه عوض شده)" };
    el.scrollIntoView({ block: "center", behavior: "instant" });
    if (a.action === "click") {
      if (el.tagName === "A" && el.target === "_blank") el.target = "_self";
      el.focus && el.focus(); el.click(); return { ok: true };
    }
    if (a.action === "type") {
      if (blocked(el)) return { ok: false, n: "BLOCKED_FIELD: اجازه‌ی پر کردن این فیلد حساس رو ندارم" };
      const tag = el.tagName; el.focus && el.focus();
      if (tag === "INPUT" || tag === "TEXTAREA") {
        const proto = tag === "INPUT" ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
        Object.getOwnPropertyDescriptor(proto, "value").set.call(el, a.text);
        el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true }));
      } else if (el.isContentEditable) {
        document.execCommand("selectAll", false, null); document.execCommand("insertText", false, a.text);
      } else return { ok: false, n: "این عنصر قابل تایپ نیست" };
      if (a.enter) {
        for (const ty of ["keydown", "keypress", "keyup"]) el.dispatchEvent(new KeyboardEvent(ty, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
        if (tag === "INPUT" && el.form && el.form.requestSubmit) { try { el.form.requestSubmit(); } catch {} }
      }
      return { ok: true };
    }
    if (a.action === "select") {
      if (el.tagName === "SELECT") {
        const want = String(a.text || "").toLowerCase();
        const o = [...el.options].find(x => x.text.trim().toLowerCase() === want) || [...el.options].find(x => x.text.toLowerCase().includes(want));
        if (!o) return { ok: false, n: "گزینه پیدا نشد" };
        el.value = o.value; el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); return { ok: true };
      }
      el.click(); return { ok: true };
    }
    return { ok: false, n: "کار ناشناخته" };
  } catch (e) { return { ok: false, n: String(e && e.message || e).slice(0, 80) }; }
}

/* ---------- رابط ---------- */
let running = false, stopFlag = false, pending = null;
function show(id, on) { $(id).hidden = !on; }
function log(kind, text) {
  const d = document.createElement("div"); d.className = kind; d.textContent = text;
  $("log").prepend(d);
}
function setRunning(on) {
  running = on; show("btnStart", !on); show("btnStop", on); $("task").disabled = on;
}
async function refreshUsage() {
  const tok = await store.get("svToken"); if (!tok) return;
  const s = await api({ mode: "agent-status", agentToken: tok }, 20000);
  if (!s.ok) { if (s.error === "AGENT_UNAUTH") { await store.del("svToken"); init(); } return; }
  $("who").textContent = s.name || "";
  const q = s.quota || {};
  $("usage").innerHTML = s.tier === "free"
    ? "🆓 <b>رایگان</b> — " + faNum(q.left) + " از " + faNum(q.cap) + " کار این هفته مانده؛ هر کار تا " + faNum(s.maxSteps) + " مرحله."
    : "⭐ <b>" + s.tierLabel + "</b> — اعتبار: " + faNum(s.credits) + " (هر مرحله حدود " + faNum(s.stepCredits) + " اعتبار)؛ هر کار تا " + faNum(s.maxSteps) + " مرحله.";
}
async function init() {
  const tok = await store.get("svToken");
  show("vConnect", !tok); show("vMain", !!tok);
  if (tok) { refreshUsage(); refreshJobs(); }
}
$("btnConnect").addEventListener("click", async () => {
  const code = $("code").value.trim(); $("connMsg").textContent = "";
  if (code.replace(/[^A-Za-z0-9]/g, "").length !== 8) { $("connMsg").textContent = "کد ۸ حرفی رو کامل بنویس."; return; }
  $("btnConnect").disabled = true;
  const r = await api({ mode: "agent-pair-redeem", code }, 25000);
  $("btnConnect").disabled = false;
  if (!r.ok) { $("connMsg").textContent = r.message || "اتصال انجام نشد."; return; }
  await store.set("svToken", r.token); $("code").value = ""; init();
});
$("btnOut").addEventListener("click", async () => { await store.del("svToken"); $("log").innerHTML = ""; init(); });
$("btnStop").addEventListener("click", () => { stopFlag = true; if (pending) pending(null); });
$("btnYes").addEventListener("click", () => pending && pending(true));
$("btnNo").addEventListener("click", () => pending && pending(false));
$("btnAskGo").addEventListener("click", () => pending && pending($("askInput").value.trim() || ""));

function ask(cardId, textId, text) {
  return new Promise(res => {
    $(textId).textContent = text; show(cardId, true);
    if (cardId === "askCard") $("askInput").value = "";
    pending = v => { pending = null; show(cardId, false); res(v); };
  });
}
const confirmUser = text => ask("confirmCard", "confirmText", text);
const askUser = text => ask("askCard", "askText", text);

async function activeTab() {
  const [t] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return t || null;
}
async function snapshot(tabId) {
  for (let i = 0; i < 2; i++) {
    try {
      const r = await chrome.scripting.executeScript({ target: { tabId }, func: svSnapshot });
      if (r && r[0] && r[0].result) return r[0].result;
    } catch (e) { /* صفحه‌ی غیرقابل‌دسترس (chrome://، فروشگاه وب …) */ }
    await sleep(700);
  }
  const t = await chrome.tabs.get(tabId).catch(() => null);
  return { url: (t && t.url) || "about:blank", title: (t && t.title) || "", text: "(این صفحه برای افزونه قابل خواندن نیست؛ اگه لازمه با goto به یک سایت برو)", els: [] };
}
async function waitComplete(tabId, ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    const t = await chrome.tabs.get(tabId).catch(() => null);
    if (!t || t.status === "complete") return;
    await sleep(300);
  }
}
function describe(a, snap) {
  const el = a.id != null ? (snap.els || []).find(q => q.i === a.id) : null, lab = el ? "«" + (el.x || el.t).slice(0, 40) + "»" : "";
  if (a.action === "click") return "کلیک روی " + lab;
  if (a.action === "type") return "نوشتن در " + lab + ": " + (a.text || "").slice(0, 60) + ((a.text || "").length > 60 ? "…" : "");
  if (a.action === "select") return "انتخاب «" + a.text + "» در " + lab;
  if (a.action === "goto") return "رفتن به " + a.url;
  if (a.action === "scroll") return a.dir === "up" ? "اسکرول به بالا" : "اسکرول به پایین";
  if (a.action === "wait") return "کمی صبر";
  return a.action;
}
const needsConfirm = (a, snap) => {
  if (a.sensitive) return true;
  if (a.action === "click" || a.action === "select") {
    const el = (snap.els || []).find(q => q.i === a.id);
    if (el && SENS_RE.test(el.x || "") && !CART_RE.test(el.x || "")) return true;
  }
  return false;
};
async function endTask(tok, taskId, status) { if (taskId) await api({ mode: "agent-end", agentToken: tok, taskId, status }, 15000); }

async function runTask(task, opts) {
  const tok = await store.get("svToken"); if (!tok) return init();
  setRunning(true); stopFlag = false; $("log").innerHTML = "";
  let taskId = "";
  try {
    const tab = (opts && opts.tabId) ? await chrome.tabs.get(opts.tabId).catch(() => null) : await activeTab();
    if (!tab) { log("err", "تب فعالی پیدا نشد."); return; }
    const tabId = tab.id, approved = new Set(); if (/^https?:/i.test(tab.url || "")) approved.add(regDomain(hostOf(tab.url)));
    const st = await api({ mode: "agent-start", agentToken: tok, task, device: "web" }, 25000);
    if (!st.ok) { log("err", st.message || "شروع نشد."); if (st.error === "AGENT_UNAUTH") { await store.del("svToken"); init(); } return; }
    taskId = st.taskId;
    /* سایتی که خودِ کاربر در متن کار نام برده، دوباره تأیید نمی‌خواهد */
    try { if (st.target && st.target.url) approved.add(regDomain(hostOf(st.target.url))); } catch {}
    log("ok", "شروع شد (" + st.tierLabel + "؛ حداکثر " + faNum(st.maxSteps) + " مرحله).");
    const history = []; let fails = 0, lastEntry = null, lastSig = "";
    const sigOf = sn => (sn.url || "") + "|" + (sn.els || []).length + "|" + String(sn.text || "").slice(0, 300) + "|" + (sn.els || []).slice(0, 12).map(q => q.x).join(";");
    for (;;) {
      if (stopFlag) { log("warn", "متوقف شد."); await endTask(tok, taskId, "stopped"); return; }
      const snap = await snapshot(tabId);
      { const sg = sigOf(snap); if (lastEntry) lastEntry.chg = sg !== lastSig; lastEntry = null; lastSig = sg; }
      if (isPayUrl(snap.url)) { log("ok", "به صفحه‌ی پرداخت رسیدیم؛ پرداخت رو خودت انجام بده. من اینجا متوقف می‌شم."); await endTask(tok, taskId, "stopped"); return; }
      const res = await api({ mode: "agent-step", agentToken: tok, taskId, page: snap, history: history.slice(-8) }, 90000);
      if (stopFlag) { log("warn", "متوقف شد."); await endTask(tok, taskId, "stopped"); return; }
      if (!res.ok) {
        if (["AGENT_NO_CREDIT", "AGENT_QUOTA", "AGENT_TASK_CLOSED", "AGENT_UNAUTH", "ACCOUNT_BLOCKED"].includes(res.error)) { log("err", res.message || "ادامه ممکن نیست."); if (res.error === "AGENT_UNAUTH") { await store.del("svToken"); init(); } return; }
        if (++fails >= 3) { log("err", (res.message || "خطا") + " — متوقف شد."); await endTask(tok, taskId, "failed"); return; }
        log("warn", (res.message || "خطای موقتی") + " — دوباره تلاش می‌کنم…"); await sleep(2000); continue;
      }
      fails = 0;
      const a = res.action;
      if (a.thought) log("th", "🧠 " + a.thought);
      if (a.action === "done") { log("ok", "✅ " + a.answer); return; }
      if (a.action === "ask") {
        log("warn", "❓ " + a.answer);
        const rep = await askUser(a.answer);
        if (rep === null) { log("warn", "متوقف شد."); await endTask(tok, taskId, "stopped"); return; }
        history.push({ a: "USER_REPLY", x: rep || "انجام شد، ادامه بده", ok: true }); continue;
      }
      const desc = describe(a, snap);
      if (a.action === "goto") {
        if (isPayUrl(a.url)) { log("ok", "این آدرس صفحه‌ی پرداخته؛ پرداخت با خودته. متوقف شدم."); await endTask(tok, taskId, "stopped"); return; }
        const dm = regDomain(hostOf(a.url));
        if (!approved.has(dm)) {
          const okd = await confirmUser("اجازه می‌دی به سایت «" + hostOf(a.url) + "» بروم؟");
          if (okd === null) { log("warn", "متوقف شد."); await endTask(tok, taskId, "stopped"); return; }
          if (!okd) { history.push({ a: "goto", x: hostOf(a.url), ok: false, n: "USER_DECLINED" }); log("warn", "رد شد: " + desc); continue; }
          approved.add(dm);
        }
      }
      if (needsConfirm(a, snap)) {
        const okc = await confirmUser("⚠️ می‌خوام این کار رو انجام بدم:\n" + desc + "\n\nتأیید می‌کنی؟");
        if (okc === null) { log("warn", "متوقف شد."); await endTask(tok, taskId, "stopped"); return; }
        if (!okc) { history.push({ a: a.action, x: desc.slice(0, 80), ok: false, n: "USER_DECLINED" }); log("warn", "رد شد: " + desc); continue; }
      }
      log("act", "▶ " + desc);
      let out = { ok: true };
      if (a.action === "goto") await chrome.tabs.update(tabId, { url: a.url });
      else if (a.action === "wait") await sleep(1500);
      else {
        try { const r = await chrome.scripting.executeScript({ target: { tabId }, func: svAct, args: [a] }); out = (r && r[0] && r[0].result) || { ok: true }; }
        catch (e) { out = { ok: true, n: "صفحه حین اجرا تغییر کرد" }; }
      }
      if (!out.ok) log("warn", "⚠ " + (out.n || "انجام نشد"));
      lastEntry = { a: a.action, x: desc.slice(0, 80), ok: out.ok !== false, n: out.n || "" }; history.push(lastEntry);
      await sleep(900); await waitComplete(tabId, 8000);
      const t2 = await chrome.tabs.get(tabId).catch(() => null);
      if (t2 && /^https?:/i.test(t2.url || "")) {
        if (isPayUrl(t2.url)) { log("ok", "به صفحه‌ی پرداخت رسیدیم؛ پرداخت رو خودت انجام بده. من اینجا متوقف می‌شم."); await endTask(tok, taskId, "stopped"); return; }
        const d2 = regDomain(hostOf(t2.url));
        if (!approved.has(d2)) {
          const okd = await confirmUser("صفحه به سایت «" + hostOf(t2.url) + "» رفت. ادامه بدم روی این سایت؟");
          if (!okd) { log("warn", "متوقف شد."); await endTask(tok, taskId, "stopped"); return; }
          approved.add(d2);
        }
      }
    }
  } finally {
    setRunning(false); pending = null; show("confirmCard", false); show("askCard", false);
    refreshUsage(); refreshJobs(); try { chrome.runtime.sendMessage({ type: "suv-poll" }).catch(() => {}); } catch {}
  }
}
$("btnStart").addEventListener("click", async () => {
  const task = $("task").value.trim();
  if (task.length < 5) { log("err", "کار رو کامل‌تر بنویس."); return; }
  let granted = false;
  try { granted = await chrome.permissions.request({ origins: ["<all_urls>"] }); } catch {}
  if (!granted) { $("log").innerHTML = ""; log("err", "برای کنترل صفحه‌ها باید اجازه‌ی دسترسی به سایت‌ها رو بدی (فقط وقتی «شروع» می‌زنی استفاده می‌شه)."); return; }
  const pt = pendingTab; pendingTab = 0;
  runTask(task, pt ? { tabId: pt } : null);
});

// ---- کاری که از چت Suvreno آمده: اتصال خودکار با کد، پرکردن کار، و شروع (اگر اجازه‌ی سایت‌ها قبلاً داده شده)
let pendingTab = 0;
async function takePending() {
  let o; try { o = (await chrome.storage.session.get("svPending")).svPending; } catch { return; }
  if (!o || Date.now() - Number(o.at || 0) > 120000) return;
  await chrome.storage.session.remove("svPending");
  if (o.code) {
    const r = await api({ mode: "agent-pair-redeem", code: o.code }, 25000);
    if (r.ok) await store.set("svToken", r.token); else { await init(); log("err", r.message || "اتصال خودکار انجام نشد."); return; }
  }
  await init();
  if (!(await store.get("svToken"))) return;
  $("task").value = o.task; pendingTab = o.tabId || 0;
  let has = false; try { has = await chrome.permissions.contains({ origins: ["<all_urls>"] }); } catch {}
  if (has) { const pt = pendingTab; pendingTab = 0; runTask(o.task, pt ? { tabId: pt } : null); }
  else { $("log").innerHTML = ""; log("ok", "کار از چت آمد. برای شروع روی «شروع» بزن (فقط بار اول اجازه‌ی دسترسی به سایت‌ها لازم است)."); }
}
chrome.runtime.onMessage.addListener((m) => { if (m && m.type === "suv-pending") takePending(); });
init().then(takePending);

/* ---------- کارهای زمان‌بندی‌شده‌ی نیازمند ورود (مرحله‌ی ۳) ---------- */
async function refreshJobs() {
  const tok = await store.get("svToken"); if (!tok) { show("jobsCard", false); return; }
  const r = await api({ mode: "agent-jobs", agentToken: tok }, 20000);
  const jobs = (r && r.ok && Array.isArray(r.jobs)) ? r.jobs : [];
  const box = $("jobsList"); box.innerHTML = ""; show("jobsCard", jobs.length > 0);
  try { chrome.action.setBadgeText({ text: jobs.length ? String(jobs.length) : "" }); } catch {}
  jobs.forEach(j => {
    const d = document.createElement("div"); d.className = "job";
    const s = document.createElement("span"); s.textContent = j.title + " — " + j.dueText;
    const b = document.createElement("button"); b.className = "pri"; b.textContent = "▶ اجرا";
    b.addEventListener("click", () => runJob(j, b));
    d.append(s, b); box.append(d);
  });
}
async function runJob(j, b) {
  if (running) { log("warn", "یک کار دیگر در حال اجراست؛ صبر کن تمام شود."); return; }
  let granted = false;
  try { granted = await chrome.permissions.request({ origins: ["<all_urls>"] }); } catch {}
  if (!granted) { $("log").innerHTML = ""; log("err", "برای کنترل صفحه‌ها باید اجازه‌ی دسترسی به سایت‌ها رو بدی (فقط وقتی «اجرا» می‌زنی استفاده می‌شه)."); return; }
  b.disabled = true;
  const tok = await store.get("svToken"); if (!tok) { init(); return; }
  const c = await api({ mode: "agent-job-claim", agentToken: tok, jobId: j.id }, 20000);
  if (!c.ok) { $("log").innerHTML = ""; log("err", c.message || "این کار الان قابل اجرا نیست."); refreshJobs(); return; }
  let tabId = 0;
  try { const tab = await chrome.tabs.create({ url: "https://www.google.com/", active: true }); tabId = tab.id; } catch {}
  $("task").value = c.task;
  await runTask(c.task, tabId ? { tabId } : null);
  refreshJobs();
}
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && (ch.svToken || ch.svJobs)) refreshJobs(); });
